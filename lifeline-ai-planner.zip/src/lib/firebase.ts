import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  projectId: "durable-tracker-z9nlt",
  appId: "1:517317337717:web:48656a13ca12b2dd994e3c",
  apiKey: "AIzaSyDj9lCysjHxNopjve1yzbP33-LhgTFPWUE",
  authDomain: "durable-tracker-z9nlt.firebaseapp.com",
  storageBucket: "durable-tracker-z9nlt.firebasestorage.app",
  messagingSenderId: "517317337717"
};

const databaseId = "ai-studio-f59f37d1-8d62-4076-b994-b1cf210ca0e0";

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, databaseId);
