import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Task, TaskDifficulty, TaskType } from "../types";
import { Calendar, AlertTriangle, Trash2, Plus, Sparkles, FileText, ChevronLeft, ArrowRight, ClipboardList } from "lucide-react";

interface TaskInputViewProps {
  initialTasks: Task[];
  onGenerate: (tasks: Task[]) => void;
  onBack: () => void;
  isGenerating: boolean;
}

export default function TaskInputView({ initialTasks, onGenerate, onBack, isGenerating }: TaskInputViewProps) {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [name, setName] = useState<string>("");
  const [deadline, setDeadline] = useState<string>("");
  const [difficulty, setDifficulty] = useState<TaskDifficulty>("Medium");
  const [type, setType] = useState<TaskType>("Study");
  const [error, setError] = useState<string>("");

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Task Name is required.");
      return;
    }
    if (!deadline) {
      setError("Please set a deadline date and time.");
      return;
    }

    const newTask: Task = {
      id: "task_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
      userId: "",
      name: name.trim(),
      deadline,
      difficulty,
      type
    };

    setTasks([...tasks, newTask]);
    setName("");
    setDeadline("");
    setDifficulty("Medium");
    setType("Study");
    setError("");
  };

  const handleRemoveTask = (id: string) => {
    setTasks(tasks.filter((t) => t.id !== id));
  };

  const handleGenerate = () => {
    if (tasks.length === 0) {
      setError("Please add at least one task for the AI to schedule.");
      return;
    }
    onGenerate(tasks);
  };

  const getDifficultyColor = (diff: TaskDifficulty) => {
    switch (diff) {
      case "Easy": return "bg-emerald-950/40 border-emerald-500/20 text-emerald-400";
      case "Medium": return "bg-blue-950/40 border-blue-500/20 text-blue-400";
      case "Hard": return "bg-rose-950/40 border-rose-500/20 text-rose-400";
    }
  };

  const getTypeIcon = (taskType: TaskType) => {
    switch (taskType) {
      case "Study": return "📚";
      case "Work": return "💻";
      case "Project": return "🚀";
      case "Assignment": return "📝";
      case "Health": return "🧘";
      case "Entertainment": return "🎮";
    }
  };

  return (
    <div id="task-input-view" className="max-w-6xl mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Task Creation Panel */}
      <motion.div
        initial={{ opacity: 0, x: -15 }}
        animate={{ opacity: 1, x: 0 }}
        className="lg:col-span-5 bg-zinc-950/80 border border-white/10 rounded p-6 backdrop-blur-md shadow-2xl h-fit"
      >
        <div className="flex items-center gap-4 mb-6">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 flex-shrink-0">
            <Plus className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-serif tracking-tight text-white">Add Tasks</h2>
            <p className="text-zinc-500 text-xs mt-0.5">Define what you must get done before deadline limits.</p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3.5 bg-red-950/20 border border-red-500/20 rounded text-red-200 text-xs font-mono flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleAddTask} className="space-y-4">
          <div>
            <label className="block text-zinc-300 text-[10px] uppercase tracking-widest font-mono mb-1.5">
              Task Name
            </label>
            <input
              id="input-task-name"
              type="text"
              placeholder="e.g. Calculus Midterm Study, Deploy staging"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-black border border-white/10 rounded px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-mono text-sm placeholder:text-zinc-700"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-zinc-300 text-[10px] uppercase tracking-widest font-mono mb-1.5">
                Type
              </label>
              <select
                id="select-task-type"
                value={type}
                onChange={(e) => setType(e.target.value as TaskType)}
                className="w-full bg-black border border-white/10 rounded px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-mono text-sm"
              >
                <option value="Study">📚 Study</option>
                <option value="Work">💻 Work</option>
                <option value="Project">🚀 Project</option>
                <option value="Assignment">📝 Assignment</option>
                <option value="Health">🧘 Health</option>
                <option value="Entertainment">🎮 Entertainment</option>
              </select>
            </div>

            <div>
              <label className="block text-zinc-300 text-[10px] uppercase tracking-widest font-mono mb-1.5">
                Difficulty
              </label>
              <select
                id="select-task-difficulty"
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as TaskDifficulty)}
                className="w-full bg-black border border-white/10 rounded px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-mono text-xs"
              >
                <option value="Easy">Easy (Low Energy)</option>
                <option value="Medium">Medium (Regular Energy)</option>
                <option value="Hard">Hard (High Intensity)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-zinc-300 text-[10px] uppercase tracking-widest font-mono mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" /> Deadline Date & Time
            </label>
            <input
              id="input-task-deadline"
              type="datetime-local"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="w-full bg-black border border-white/10 rounded px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-mono text-sm"
            />
          </div>

          <button
            type="submit"
            id="btn-add-task"
            className="flex items-center justify-center gap-2 w-full py-3.5 bg-zinc-900 border border-white/10 hover:bg-zinc-850 hover:border-white/20 text-white font-mono text-xs uppercase tracking-widest rounded transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" /> Add Task to List
          </button>
        </form>
      </motion.div>

      {/* Task List Panel */}
      <motion.div
        initial={{ opacity: 0, x: 15 }}
        animate={{ opacity: 1, x: 0 }}
        className="lg:col-span-7 flex flex-col justify-between bg-zinc-950/50 border border-white/10 rounded p-6 backdrop-blur-md shadow-2xl"
      >
        <div>
          <div className="flex items-center justify-between mb-6 border-b border-white/10 pb-4">
            <div className="flex items-center gap-2.5">
              <ClipboardList className="w-4.5 h-4.5 text-emerald-400" />
              <h3 className="text-lg font-serif tracking-tight text-white">Your Scheduled Pipeline</h3>
            </div>
            <span className="text-[10px] font-mono uppercase tracking-wider bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold px-2.5 py-0.5 rounded">
              {tasks.length} {tasks.length === 1 ? "Task" : "Tasks"} Total
            </span>
          </div>

          {tasks.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-white/10 rounded bg-black/30 px-4">
              <FileText className="w-10 h-10 text-zinc-700 mb-3" />
              <p className="text-zinc-400 font-medium text-sm">No tasks added yet.</p>
              <p className="text-[11px] text-zinc-600 mt-1 max-w-sm leading-relaxed">
                Add your upcoming examinations, assignments, office deliverables, workouts, or recreational activities on the left.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
              <AnimatePresence initial={false}>
                {tasks.map((task) => (
                  <motion.div
                    key={task.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    className="flex items-center justify-between p-3 bg-black border border-white/5 rounded hover:border-white/15 transition-all gap-4"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="text-lg p-2 bg-zinc-950 border border-white/5 rounded flex-shrink-0">
                        {getTypeIcon(task.type)}
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-white font-medium text-sm truncate">{task.name}</h4>
                        <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px]">
                          <span className={`px-1.5 py-0.5 rounded border text-[9px] font-bold uppercase tracking-wider ${getDifficultyColor(task.difficulty)}`}>
                            {task.difficulty}
                          </span>
                          <span className="text-zinc-500 font-mono">
                            Due: {new Date(task.deadline).toLocaleString([], { dateStyle: "short", timeStyle: "short" })}
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      id={`btn-remove-task-${task.id}`}
                      onClick={() => handleRemoveTask(task.id)}
                      className="p-2 text-zinc-600 hover:text-emerald-400 hover:bg-emerald-500/10 rounded transition-colors flex-shrink-0 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* Generate triggers */}
        <div className="flex items-center justify-between border-t border-white/10 pt-6 mt-6">
          <button
            type="button"
            id="btn-tasks-back"
            onClick={onBack}
            className="flex items-center gap-1.5 px-4 py-2 text-zinc-500 hover:text-white font-mono text-xs uppercase tracking-widest transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" /> Back
          </button>

          <button
            type="button"
            id="btn-generate-schedule"
            onClick={handleGenerate}
            disabled={tasks.length === 0 || isGenerating}
            className="group flex items-center justify-center gap-2.5 px-7 py-3.5 bg-emerald-500 disabled:bg-zinc-900 disabled:text-zinc-600 disabled:cursor-not-allowed text-black font-bold font-mono text-xs uppercase tracking-widest rounded transition-all duration-300 hover:bg-emerald-400 cursor-pointer"
          >
            {isGenerating ? (
              <>
                <svg className="animate-spin h-3.5 w-3.5 text-black" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>AI Constructing...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-black animate-pulse" />
                <span>Optimize Full Schedule</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
