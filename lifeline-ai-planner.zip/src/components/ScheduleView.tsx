import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Schedule, TaskDifficulty, TaskType, UserProfile, Task } from "../types";
import { 
  CheckCircle, 
  HelpCircle, 
  Coffee, 
  RefreshCw, 
  Check, 
  Brain, 
  Sparkles, 
  Lightbulb, 
  Clock, 
  BookOpen, 
  Smile, 
  ListTodo, 
  AlertCircle,
  MessageSquare,
  X
} from "lucide-react";
import CoachChatView from "./CoachChatView";

interface ScheduleViewProps {
  schedule: Schedule;
  onAccept: () => void;
  onReschedule: (feedbackText: string) => void;
  isRescheduling: boolean;
  onRestart: () => void;
  onToggleBlock?: (blockIndex: number) => void;
  userId: string;
  profile: UserProfile | null;
  tasks: Task[];
}

export default function ScheduleView({ 
  schedule, 
  onAccept, 
  onReschedule, 
  isRescheduling, 
  onRestart,
  onToggleBlock,
  userId,
  profile,
  tasks
}: ScheduleViewProps) {
  const [showRescheduleForm, setShowRescheduleForm] = useState<boolean>(false);
  const [showCoachChat, setShowCoachChat] = useState<boolean>(false);
  const [feedbackInput, setFeedbackInput] = useState<string>("");
  const [rescheduleError, setRescheduleError] = useState<string>("");
  const [acceptedState, setAcceptedState] = useState<boolean>(schedule.feedback === "accepted");

  const handleAcceptClick = () => {
    setAcceptedState(true);
    onAccept();
  };

  const handleRescheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackInput.trim()) {
      setRescheduleError("Please write what you would like to improve.");
      return;
    }
    setRescheduleError("");
    onReschedule(feedbackInput.trim());
    setShowRescheduleForm(false);
    setFeedbackInput("");
  };

  const getDifficultyColor = (diff: TaskDifficulty | "None") => {
    switch (diff) {
      case "Easy": return "bg-emerald-500/10 border-emerald-500/20 text-emerald-400 text-[10px]";
      case "Medium": return "bg-amber-500/10 border-amber-500/20 text-amber-400 text-[10px]";
      case "Hard": return "bg-rose-500/10 border-rose-500/20 text-rose-400 text-[10px]";
      default: return "hidden";
    }
  };

  const getBlockStyles = (type: string) => {
    switch (type) {
      case "Break":
        return {
          bg: "bg-blue-950/5 border-blue-500/10",
          accent: "border-l-2 border-l-blue-500",
          icon: <Coffee className="w-4 h-4 text-blue-400" />
        };
      case "Productive Activity":
        return {
          bg: "bg-emerald-950/5 border-emerald-500/15",
          accent: "border-l-2 border-l-emerald-500",
          icon: <Sparkles className="w-4 h-4 text-emerald-400" />
        };
      case "Entertainment":
        return {
          bg: "bg-zinc-950/40 border-white/5",
          accent: "border-l-2 border-l-zinc-600",
          icon: <span>🎮</span>
        };
      default:
        return {
          bg: "bg-zinc-900/80 border-white/10",
          accent: "border-l-2 border-l-emerald-500",
          icon: <span>📚</span>
        };
    }
  };

  return (
    <div id="schedule-view" className="max-w-6xl mx-auto px-4 py-6 space-y-8">
      {/* Upper Status/Accept Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 bg-zinc-950/80 border border-white/10 rounded p-6 backdrop-blur-md">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 flex-shrink-0">
            <Brain className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-serif tracking-tight text-white flex items-center gap-2">
              Adaptive Schedule Generated
            </h2>
            <p className="text-zinc-500 text-xs mt-0.5">
              Optimized daily pipeline based on critical deadlines and balanced cognitive loads.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          {acceptedState ? (
            <div className="flex items-center gap-2 px-6 py-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold rounded font-mono text-xs uppercase tracking-widest w-full md:w-auto justify-center">
              <Check className="w-4 h-4" /> Committed to Lifeline!
            </div>
          ) : (
            <>
              <button
                type="button"
                id="btn-reschedule-trigger"
                onClick={() => setShowRescheduleForm(true)}
                disabled={isRescheduling}
                className="flex items-center justify-center gap-2 px-5 py-3 border border-white/10 bg-black hover:bg-zinc-900 text-zinc-300 font-mono text-xs uppercase tracking-widest rounded w-1/2 md:w-auto cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRescheduling ? "animate-spin" : ""}`} />
                <span>Reschedule</span>
              </button>

              <button
                type="button"
                id="btn-accept-schedule"
                onClick={handleAcceptClick}
                className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded font-mono text-xs uppercase tracking-widest w-1/2 md:w-auto cursor-pointer"
              >
                <CheckCircle className="w-4 h-4 text-black" />
                <span>I Can Do It</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Recommended Time Blocks Chronological Timeline */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex items-center gap-2.5 border-b border-white/10 pb-3 mb-2">
            <Clock className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-serif tracking-tight text-white">Your Optimization Plan</h3>
          </div>

          {(() => {
            // Group blocks by date
            const blocksByDate: { [date: string]: typeof schedule.timeBlocks } = {};
            schedule.timeBlocks.forEach((block) => {
              const dKey = block.date || "Today";
              if (!blocksByDate[dKey]) {
                blocksByDate[dKey] = [];
              }
              blocksByDate[dKey].push(block);
            });

            const sortedDates = Object.keys(blocksByDate).sort();

            if (sortedDates.length === 0) {
              return (
                <div className="text-center py-8 text-zinc-500 text-xs font-mono">
                  No scheduled blocks generated.
                </div>
              );
            }

            return sortedDates.map((dateStr) => {
              let displayHeader = dateStr;
              try {
                const dateObj = new Date(dateStr + "T00:00:00");
                if (!isNaN(dateObj.getTime())) {
                  displayHeader = dateObj.toLocaleDateString("en-US", {
                    weekday: "long",
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                  });
                }
              } catch (e) {
                // fallback to original dateStr
              }

              return (
                <div key={dateStr} className="space-y-4">
                  <div className="flex items-center gap-2 pt-2">
                    <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded">
                      📅 {displayHeader}
                    </span>
                  </div>

                  <div className="relative border-l border-white/10 ml-3.5 pl-6 space-y-4">
                    {blocksByDate[dateStr].map((block) => {
                      // Find actual index in global schedule.timeBlocks
                      const originalIdx = schedule.timeBlocks.findIndex((b) => b === block);
                      const style = getBlockStyles(block.type);
                      return (
                        <motion.div
                          key={`${originalIdx}-${block.startTime}`}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="relative group"
                        >
                          {/* Outer Timeline Dot */}
                          <span className="absolute -left-[31px] top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-zinc-800 border-2 border-zinc-950 group-hover:bg-emerald-500 group-hover:border-emerald-400 transition-colors" />

                          {/* Time Block Card */}
                          <div className={`p-4 border rounded backdrop-blur-md transition-all duration-300 ${
                            block.completed 
                              ? "bg-zinc-950/20 border-emerald-500/10 opacity-50" 
                              : style.bg
                          } ${block.completed ? "border-l-2 border-l-emerald-500/40" : style.accent} flex items-center justify-between gap-4`}>
                            <div className="flex items-start gap-3.5 min-w-0 flex-1">
                              {/* Interactive Checklist Checkbox */}
                              <button
                                type="button"
                                onClick={() => onToggleBlock && onToggleBlock(originalIdx !== -1 ? originalIdx : 0)}
                                className={`mt-0.5 flex-shrink-0 w-5 h-5 rounded border flex items-center justify-center transition-all duration-200 cursor-pointer ${
                                  block.completed 
                                    ? "bg-emerald-500/20 border-emerald-500 text-emerald-400" 
                                    : "border-white/20 hover:border-emerald-500/50 bg-black/40 text-transparent"
                                }`}
                                title={block.completed ? "Mark as incomplete" : "Mark as complete"}
                              >
                                <Check className={`w-3.5 h-3.5 transition-transform duration-200 ${block.completed ? "scale-100" : "scale-0"}`} />
                              </button>

                              <div className="space-y-1 min-w-0 flex-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[10px] text-emerald-400 font-mono bg-black px-2 py-0.5 rounded border border-white/5">
                                    {block.startTime} - {block.endTime}
                                  </span>
                                  {block.isProductiveSuggestion && (
                                    <span className="text-[9px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 uppercase tracking-wider">
                                      <Sparkles className="w-2.5 h-2.5 text-emerald-400" /> AI Suggested
                                    </span>
                                  )}
                                  <span className={`px-1.5 py-0.2 rounded border font-mono uppercase tracking-widest text-[9px] font-bold ${getDifficultyColor(block.difficulty)}`}>
                                    {block.difficulty}
                                  </span>
                                </div>
                                <h4 className={`text-white font-medium text-sm truncate transition-all duration-200 ${block.completed ? "line-through text-zinc-500" : ""}`}>{block.title}</h4>
                                <p className={`text-zinc-500 text-xs line-clamp-2 leading-relaxed transition-all duration-200 ${block.completed ? "text-zinc-600" : ""}`}>{block.description}</p>
                              </div>
                            </div>

                            <div className={`p-2.5 bg-black border border-white/5 rounded flex-shrink-0 flex items-center justify-center transition-all duration-200 ${block.completed ? "opacity-30" : ""}`}>
                              {style.icon}
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              );
            });
          })()}

          {/* Ask Lifeline AI Coach Trigger Block */}
          <div className="mt-8 p-6 bg-zinc-950/80 border border-emerald-500/20 hover:border-emerald-500/40 rounded flex flex-col sm:flex-row items-center justify-between gap-4 transition-all duration-300">
            <div className="space-y-1 text-center sm:text-left">
              <h4 className="text-sm font-serif text-white flex items-center justify-center sm:justify-start gap-2">
                <Brain className="w-4 h-4 text-emerald-400 animate-pulse" />
                Ask Lifeline AI Coach
              </h4>
              <p className="text-xs text-zinc-500 max-w-md leading-relaxed">
                Receive strict but helpful productivity advice, plan task decisions, or ask how to optimize your schedule.
              </p>
            </div>
            <button
              type="button"
              id="btn-ask-coach-trigger"
              onClick={() => setShowCoachChat(true)}
              className="w-full sm:w-auto px-6 py-3 bg-zinc-900 border border-emerald-500/30 hover:border-emerald-400 text-emerald-400 hover:text-white font-bold font-mono text-xs uppercase tracking-widest rounded transition-all duration-300 cursor-pointer flex items-center justify-center gap-2 flex-shrink-0"
            >
              Ask Lifeline AI Coach
            </button>
          </div>

          {/* Start Again / Exit Block at the end of Today's Strategy */}
          <div className="mt-8 p-6 bg-zinc-950/60 border border-white/10 rounded flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <h4 className="text-sm font-serif text-white">Completed today's strategy planning?</h4>
              <p className="text-xs text-zinc-500 max-w-md leading-relaxed">
                You can exit this schedule, reset parameters, or start planning a completely new day anytime.
              </p>
            </div>
            <button
              id="btn-timeline-start-again"
              onClick={onRestart}
              className="w-full sm:w-auto px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-bold font-mono text-xs uppercase tracking-widest rounded transition-all duration-300 hover:shadow-[0_0_25px_rgba(16,185,129,0.25)] hover:scale-[1.01] cursor-pointer flex items-center justify-center gap-2 flex-shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Start Again</span>
            </button>
          </div>
        </div>

        {/* Right Panel: Recommendations & Explainability */}
        <div className="lg:col-span-5 space-y-6">
          {/* Explainability Panel */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-zinc-950/80 border border-white/10 rounded p-6 backdrop-blur-md space-y-4"
          >
            <div className="flex items-center gap-2.5 border-b border-white/10 pb-3">
              <Lightbulb className="w-4.5 h-4.5 text-emerald-400" />
              <h3 className="text-md font-serif tracking-tight text-white">Gemini Reasoning</h3>
            </div>

            <div className="space-y-4 text-xs text-zinc-400 leading-relaxed">
              <p className="font-semibold text-zinc-500 italic">
                “Here is why I selected this sequence of work, breaks, and suggested activities:”
              </p>
              <div className="p-3.5 bg-black border border-white/5 rounded font-mono text-[11px] space-y-1.5 whitespace-pre-wrap leading-relaxed text-zinc-300">
                {schedule.explanation}
              </div>

              {/* Categorized Factors */}
              <div className="grid grid-cols-2 gap-3 mt-4 text-[10px]">
                <div className="p-3 bg-black border border-white/5 rounded space-y-1">
                  <h4 className="font-bold text-rose-400 uppercase tracking-wider font-mono">Urgency Rating</h4>
                  <p className="text-zinc-500">Closer deadlines scheduled first with safety buffers.</p>
                </div>
                <div className="p-3 bg-black border border-white/5 rounded space-y-1">
                  <h4 className="font-bold text-emerald-400 uppercase tracking-wider font-mono">Cognitive Energy</h4>
                  <p className="text-zinc-500">Peak energy matching heavy strategic slots.</p>
                </div>
                <div className="p-3 bg-black border border-white/5 rounded space-y-1 col-span-2">
                  <h4 className="font-bold text-blue-400 uppercase tracking-wider font-mono">Optimized Transitions</h4>
                  <p className="text-zinc-500">Recovery blocks delay dopamine depletion & balance study cycles.</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Productivity Advice List */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-zinc-950/80 border border-white/10 rounded p-6 backdrop-blur-md space-y-4"
          >
            <div className="flex items-center gap-2.5 border-b border-white/10 pb-3">
              <ListTodo className="w-4.5 h-4.5 text-emerald-400" />
              <h3 className="text-md font-serif tracking-tight text-white">Tactical Tips</h3>
            </div>

            <ul className="space-y-3">
              {schedule.recommendations.map((rec, i) => (
                <li key={i} className="flex items-start gap-2.5 text-xs text-zinc-400 leading-relaxed">
                  <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Restart button */}
          <div className="flex justify-end pt-2">
            <button
              id="btn-restart-flow"
              onClick={onRestart}
              className="text-xs text-zinc-500 hover:text-white transition-colors cursor-pointer border border-white/5 hover:border-white/15 bg-black px-4 py-2 rounded font-mono uppercase tracking-widest"
            >
              Reset Schedule
            </button>
          </div>
        </div>
      </div>

      {/* Reschedule Overlay Dialog */}
      <AnimatePresence>
        {showRescheduleForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.98, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.98, opacity: 0 }}
              className="relative w-full max-w-lg bg-zinc-950 border border-white/10 rounded p-6 shadow-2xl"
            >
              <button
                type="button"
                id="btn-close-reschedule"
                onClick={() => setShowRescheduleForm(false)}
                className="absolute right-4 top-4 p-1.5 text-zinc-500 hover:text-white hover:bg-zinc-900 rounded cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-4 mb-5">
                <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 flex-shrink-0">
                  <RefreshCw className="w-5 h-5 animate-spin" style={{ animationDuration: "12s" }} />
                </div>
                <div>
                  <h3 className="text-lg font-serif tracking-tight text-white">Re-align Schedule</h3>
                  <p className="text-xs text-zinc-500 mt-0.5">Let Gemini regenerate and resolve specific conflicts.</p>
                </div>
              </div>

              {rescheduleError && (
                <div className="mb-4 p-3.5 bg-red-950/20 border border-red-500/20 rounded text-red-200 text-xs font-mono flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  <span>{rescheduleError}</span>
                </div>
              )}

              <form onSubmit={handleRescheduleSubmit} className="space-y-4">
                <div>
                  <label className="block text-zinc-300 text-[10px] uppercase tracking-widest font-mono mb-2">
                    How should the AI adjust your schedule?
                  </label>
                  <textarea
                    id="input-reschedule-feedback"
                    rows={4}
                    placeholder="e.g., I need a longer lunch break. Put more study blocks in the early morning and move entertainment later."
                    value={feedbackInput}
                    onChange={(e) => setFeedbackInput(e.target.value)}
                    className="w-full bg-black border border-white/10 rounded px-3 py-3 text-white focus:outline-none focus:border-emerald-500 font-mono text-sm placeholder-zinc-700 resize-none leading-relaxed"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    id="btn-cancel-reschedule"
                    onClick={() => setShowRescheduleForm(false)}
                    className="px-4 py-2 text-xs text-zinc-500 hover:text-white font-mono uppercase tracking-widest cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    id="btn-submit-reschedule"
                    className="flex items-center gap-1.5 px-5 py-2.5 bg-emerald-500 text-black font-bold font-mono text-xs uppercase tracking-widest rounded transition-all hover:bg-emerald-400 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Regenerate Now</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {showCoachChat && (
          <CoachChatView
            userId={userId}
            profile={profile}
            tasks={tasks}
            schedule={schedule}
            isOpen={showCoachChat}
            onClose={() => setShowCoachChat(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
