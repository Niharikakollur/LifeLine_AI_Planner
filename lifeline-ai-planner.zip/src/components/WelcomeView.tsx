import React from "react";
import { motion } from "motion/react";
import { Calendar, ShieldAlert, Sparkles, Zap, Timer } from "lucide-react";

interface WelcomeViewProps {
  onStart: () => void;
}

export default function WelcomeView({ onStart }: WelcomeViewProps) {
  return (
    <div id="welcome-view" className="flex flex-col items-center justify-center min-h-[75vh] px-4 text-center max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: -15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-6 inline-flex items-center gap-2 bg-emerald-950/30 border border-emerald-500/20 px-4 py-2 rounded text-emerald-400 text-xs font-mono tracking-wider uppercase"
      >
        <Timer className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
        MAXIMUM INTENSITY WORK MANAGEMENT
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.1 }}
        className="text-4xl sm:text-6xl md:text-7xl font-serif tracking-tight text-white max-w-3xl leading-tight"
      >
        Master your time before <br />
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-500 italic">
          your deadlines master you.
        </span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="mt-6 text-zinc-400 text-sm sm:text-base max-w-xl leading-relaxed"
      >
        Lifeline AI is a premium, zero-burnout scheduling engine that shields you from looming deadlines. We organize your obligations, insert balanced recovery breaks, and optimize empty slots.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="mt-10 w-full sm:w-auto"
      >
        <button
          id="btn-start"
          onClick={onStart}
          className="group relative flex items-center justify-center gap-3 w-full sm:w-auto px-10 py-4.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold uppercase tracking-widest text-xs rounded transition-all duration-300 hover:shadow-[0_0_30px_rgba(16,185,129,0.3)] hover:scale-[1.01] cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-black animate-spin" style={{ animationDuration: "4s" }} />
          <span>Launch AI Planner</span>
          <Zap className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </button>
      </motion.div>

      {/* Trust & Technology Badges */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl border-t border-white/10 pt-10 text-left w-full"
      >
        <div className="flex items-start gap-3.5 p-4 bg-zinc-950/40 border border-white/5 rounded-lg">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-white font-medium text-xs uppercase tracking-wider font-mono">Crisis Handling</h4>
            <p className="text-zinc-400 text-xs mt-1.5 leading-relaxed">Prioritizes assignments and exams over simple chronological deadlines.</p>
          </div>
        </div>

        <div className="flex items-start gap-3.5 p-4 bg-zinc-950/40 border border-white/5 rounded-lg">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-white font-medium text-xs uppercase tracking-wider font-mono">Energy Regulator</h4>
            <p className="text-zinc-400 text-xs mt-1.5 leading-relaxed">Balanced 10-60 minute recovery blocks strategically injected after heavy exertion.</p>
          </div>
        </div>

        <div className="flex items-start gap-3.5 p-4 bg-zinc-950/40 border border-white/5 rounded-lg">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-white font-medium text-xs uppercase tracking-wider font-mono">Zero-Gap Planner</h4>
            <p className="text-zinc-400 text-xs mt-1.5 leading-relaxed">Fills scheduling voids with healthy secondary tasks like Revision or Gym blocks.</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
