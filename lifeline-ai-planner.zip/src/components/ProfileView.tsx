import React, { useState } from "react";
import { motion } from "motion/react";
import { UserProfile } from "../types";
import { ArrowRight, Brain, Clock, Moon, Sun, UserCheck } from "lucide-react";

interface ProfileViewProps {
  initialProfile: UserProfile | null;
  onSave: (profile: UserProfile) => void;
  onBack: () => void;
}

export default function ProfileView({ initialProfile, onSave, onBack }: ProfileViewProps) {
  const [role, setRole] = useState<UserProfile["role"]>(initialProfile?.role || "Student");
  const [dailyFreeHours, setDailyFreeHours] = useState<number>(initialProfile?.dailyFreeHours || 6);
  const [wakeUpTime, setWakeUpTime] = useState<string>(initialProfile?.wakeUpTime || "07:00");
  const [currentStartTime, setCurrentStartTime] = useState<string>(initialProfile?.currentStartTime || "");
  const [sleepTime, setSleepTime] = useState<string>(initialProfile?.sleepTime || "23:00");
  const [error, setError] = useState<string>("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (dailyFreeHours < 1 || dailyFreeHours > 24) {
      setError("Daily free hours must be between 1 and 24 hours.");
      return;
    }
    setError("");
    onSave({
      userId: initialProfile?.userId || "",
      role,
      dailyFreeHours,
      wakeUpTime,
      sleepTime,
      currentStartTime
    });
  };

  return (
    <div id="profile-view" className="max-w-xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-zinc-950/80 border border-white/10 rounded p-6 md:p-8 backdrop-blur-md shadow-2xl"
      >
        <div className="flex items-center gap-4 mb-8">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 flex-shrink-0">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-2xl font-serif tracking-tight text-white">Sleep & Allocation</h2>
            <p className="text-zinc-500 text-xs mt-0.5">Configure your standard operational window & available capacity.</p>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-950/20 border border-red-500/20 rounded text-red-200 text-xs font-mono">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Occupation / Role selector */}
          <div>
            <label className="block text-zinc-300 text-xs uppercase tracking-widest font-mono mb-3 flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-emerald-400" /> Identity Mode
            </label>
            <div className="grid grid-cols-3 gap-3">
              {(["Student", "Employee", "Other"] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  id={`role-btn-${option.toLowerCase()}`}
                  onClick={() => setRole(option)}
                  className={`py-3 px-2 rounded font-mono text-xs uppercase tracking-widest border transition-all ${
                    role === option
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-400 font-bold"
                      : "bg-black border-white/5 hover:border-white/15 text-zinc-400"
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>

          {/* Daily free hours slider */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-zinc-300 text-xs uppercase tracking-widest font-mono flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-400" /> Allocated Hours
              </label>
              <span className="text-emerald-400 font-mono text-xs bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/25">
                {dailyFreeHours} {dailyFreeHours === 1 ? "Hour" : "Hours"}
              </span>
            </div>
            <p className="text-[11px] text-zinc-500 mb-4 leading-relaxed">
              Define the number of hours you can actively dedicate today to work, studies, or secondary activities.
            </p>
            <input
              id="input-daily-free-hours"
              type="range"
              min="1"
              max="24"
              value={dailyFreeHours}
              onChange={(e) => setDailyFreeHours(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-zinc-600 px-1 mt-1">
              <span>1 Hour</span>
              <span>12 Hours</span>
              <span>24 Hours</span>
            </div>
          </div>

          {/* Sleep & Wake Cycles */}
          <div className="space-y-4">
            <div>
              <label className="block text-zinc-300 text-xs uppercase tracking-widest font-mono mb-2 flex items-center gap-1.5">
                <Sun className="w-4 h-4 text-emerald-400" /> Start (Wake)
              </label>
              <input
                id="input-wake-time"
                type="time"
                value={wakeUpTime}
                onChange={(e) => setWakeUpTime(e.target.value)}
                className="w-full bg-black border border-white/10 rounded px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-mono text-sm"
                required
              />
            </div>

            <div>
              <label className="block text-zinc-300 text-xs uppercase tracking-widest font-mono mb-2 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-emerald-400" /> Current Start Time
              </label>
              <input
                id="input-current-start-time"
                type="text"
                placeholder="What time are you starting work now?"
                value={currentStartTime}
                onChange={(e) => setCurrentStartTime(e.target.value)}
                className="w-full bg-black border border-white/10 rounded px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-mono text-sm"
              />
              <p className="text-[11px] text-zinc-500 mt-1">
                Example: 6:30 PM. Leaving this empty defaults to standard wake-up time.
              </p>
            </div>

            <div>
              <label className="block text-zinc-300 text-xs uppercase tracking-widest font-mono mb-2 flex items-center gap-1.5">
                <Moon className="w-4 h-4 text-blue-400" /> Cutoff (Sleep)
              </label>
              <input
                id="input-sleep-time"
                type="time"
                value={sleepTime}
                onChange={(e) => setSleepTime(e.target.value)}
                className="w-full bg-black border border-white/10 rounded px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-mono text-sm"
                required
              />
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-6 border-t border-white/10 mt-8">
            <button
              type="button"
              id="btn-profile-back"
              onClick={onBack}
              className="px-5 py-3 text-zinc-500 hover:text-white font-mono text-xs uppercase tracking-widest transition-colors cursor-pointer"
            >
              Back
            </button>
            <button
              type="submit"
              id="btn-profile-next"
              className="flex items-center gap-2 px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-mono text-xs font-bold uppercase tracking-widest rounded transition-all cursor-pointer"
            >
              <span>Set Tasks</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
