import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { MessageSquare, Send, X, Brain, Sparkles, AlertCircle, RefreshCw, Flame, HelpCircle } from "lucide-react";
import { UserProfile, Task, Schedule } from "../types";

interface Message {
  role: "user" | "assistant" | "model";
  text: string;
  timestamp?: string;
}

interface CoachChatViewProps {
  userId: string;
  profile: UserProfile | null;
  tasks: Task[];
  schedule: Schedule | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function CoachChatView({
  userId,
  profile,
  tasks,
  schedule,
  isOpen,
  onClose
}: CoachChatViewProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Fetch history on mount / when isOpen changes to true
  useEffect(() => {
    if (!isOpen || !userId) return;

    async function fetchChatHistory() {
      setIsInitializing(true);
      setErrorMessage("");
      try {
        const res = await fetch(`/api/get-coach-chat/${userId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.messages && data.messages.length > 0) {
            setMessages(data.messages);
          } else {
            // Seed initial message from Coach if none exist
            const initialText = "I am your Lifeline AI Coach. I have analyzed your schedule and deadlines. What excuse, delay, or decision is blocking your execution right now? Tell me the truth, and let's optimize.";
            setMessages([{ role: "assistant", text: initialText }]);
          }
        } else {
          setErrorMessage("Failed to load coaching history.");
        }
      } catch (e) {
        console.error("Error loading chat history:", e);
        setErrorMessage("Connection error while loading coach.");
      } finally {
        setIsInitializing(false);
      }
    }

    fetchChatHistory();
  }, [isOpen, userId]);

  // Scroll to bottom on message change
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;

    const userText = inputText.trim();
    setInputText("");
    setErrorMessage("");

    // 1. Append User Message Locally
    const newMsg: Message = { role: "user", text: userText };
    setMessages(prev => [...prev, newMsg]);
    setIsLoading(true);

    try {
      // 2. Persist User Message in Firestore
      await fetch("/api/save-coach-message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, role: "user", text: userText })
      });

      // 3. Request AI reply from server
      const currentHistory = [...messages, newMsg];
      const res = await fetch("/api/coach-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          messages: currentHistory,
          profile,
          tasks,
          schedule
        })
      });

      if (!res.ok) {
        throw new Error("Coach was unable to formulate a response.");
      }

      const data = await res.json();
      const coachReplyText = data.reply;

      // 4. Append Coach Reply Locally
      const coachMsg: Message = { role: "assistant", text: coachReplyText };
      setMessages(prev => [...prev, coachMsg]);

      // 5. Persist Coach Reply in Firestore
      await fetch("/api/save-coach-message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, role: "assistant", text: coachReplyText })
      });

    } catch (error: any) {
      console.error("Coaching chat error:", error);
      setErrorMessage(error.message || "Failed to communicate with Coach.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <motion.div
        initial={{ scale: 0.98, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.98, opacity: 0 }}
        className="relative w-full max-w-2xl h-[85vh] bg-zinc-950 border border-white/10 rounded flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-zinc-950">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/25 rounded text-emerald-400">
              <Brain className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-md font-serif text-white tracking-tight flex items-center gap-1.5">
                Lifeline AI Coach <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded uppercase">Strict Mentor</span>
              </h3>
              <p className="text-[11px] text-zinc-500 font-sans mt-0.5">
                Your direct productivity strategist. No excuses, pure optimization.
              </p>
            </div>
          </div>
          <button
            type="button"
            id="btn-close-coach"
            onClick={onClose}
            className="p-1.5 text-zinc-500 hover:text-white hover:bg-zinc-900 rounded cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Error strip */}
        {errorMessage && (
          <div className="p-3 bg-rose-950/20 border-b border-rose-500/20 text-rose-200 text-xs font-mono flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-zinc-950/40 font-sans text-sm">
          {isInitializing ? (
            <div className="h-full flex flex-col items-center justify-center gap-2 text-zinc-500 text-xs font-mono">
              <RefreshCw className="w-5 h-5 animate-spin text-emerald-400" />
              <span>Initializing Coaching Interface...</span>
            </div>
          ) : (
            <>
              {messages.map((msg, index) => {
                const isUser = msg.role === "user";
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className={`flex ${isUser ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[85%] rounded p-4 border leading-relaxed text-xs whitespace-pre-wrap ${
                        isUser
                          ? "bg-zinc-900 border-white/10 text-white"
                          : "bg-emerald-500/5 border-emerald-500/10 text-emerald-100"
                      }`}
                    >
                      {!isUser && (
                        <div className="flex items-center gap-1.5 mb-1.5 text-[9px] uppercase tracking-widest font-mono font-bold text-emerald-400">
                          <Sparkles className="w-3 h-3" />
                          <span>AI Coach Advice</span>
                        </div>
                      )}
                      {isUser && (
                        <div className="flex items-center gap-1.5 mb-1.5 text-[9px] uppercase tracking-widest font-mono font-bold text-zinc-500">
                          <span>You</span>
                        </div>
                      )}
                      <div>{msg.text}</div>
                    </div>
                  </motion.div>
                );
              })}

              {isLoading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-start"
                >
                  <div className="max-w-[85%] rounded p-4 bg-emerald-500/5 border border-emerald-500/10 text-zinc-500 text-xs font-mono flex items-center gap-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                    <span>Coach is reviewing your decisions...</span>
                  </div>
                </motion.div>
              )}
              <div ref={chatEndRef} />
            </>
          )}
        </div>

        {/* Suggestion Prompts bar */}
        <div className="px-6 py-2.5 bg-black/60 border-t border-white/10 flex items-center gap-2 overflow-x-auto whitespace-nowrap">
          <span className="text-[10px] uppercase font-mono text-zinc-600 tracking-wider">Quick Prompts:</span>
          <button
            type="button"
            onClick={() => setInputText("I feel tired and cannot study.")}
            className="px-2.5 py-1 text-[11px] bg-zinc-900 hover:bg-zinc-800 text-zinc-400 border border-white/5 rounded cursor-pointer transition-all"
          >
            "I feel tired and cannot study"
          </button>
          <button
            type="button"
            onClick={() => setInputText("Can I watch a movie now?")}
            className="px-2.5 py-1 text-[11px] bg-zinc-900 hover:bg-zinc-800 text-zinc-400 border border-white/5 rounded cursor-pointer transition-all"
          >
            "Can I watch a movie now?"
          </button>
          <button
            type="button"
            onClick={() => setInputText("I cannot follow this schedule.")}
            className="px-2.5 py-1 text-[11px] bg-zinc-900 hover:bg-zinc-800 text-zinc-400 border border-white/5 rounded cursor-pointer transition-all"
          >
            "I cannot follow this schedule"
          </button>
        </div>

        {/* Message Input Form */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-white/10 bg-zinc-950 flex items-center gap-3">
          <input
            id="coach-chat-input"
            type="text"
            placeholder={isLoading ? "Please wait..." : "Type your decision or excuse here..."}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isLoading || isInitializing}
            className="flex-1 bg-black border border-white/10 rounded px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono placeholder-zinc-700"
            autoComplete="off"
          />
          <button
            type="submit"
            id="btn-send-coach-msg"
            disabled={!inputText.trim() || isLoading || isInitializing}
            className="p-3 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            title="Send advice request"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </motion.div>
    </div>
  );
}
