import React, { useState, useEffect } from "react";
import { UserProfile, Task, Schedule } from "./types";
import WelcomeView from "./components/WelcomeView";
import ProfileView from "./components/ProfileView";
import TaskInputView from "./components/TaskInputView";
import ScheduleView from "./components/ScheduleView";
import { Brain, Flame, RefreshCw, Sparkles, User, AlertCircle, Info } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [userId, setUserId] = useState<string>("");
  const [step, setStep] = useState<"welcome" | "profile" | "tasks" | "schedule">("welcome");
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [schedule, setSchedule] = useState<Schedule | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [successMsg, setSuccessMsg] = useState<string>("");

  // Restore/generate userId and retrieve user data from Firestore on mount
  useEffect(() => {
    async function restoreSession() {
      let currentId = localStorage.getItem("lifeline_user_id");
      if (!currentId) {
        currentId = "user_" + Math.random().toString(36).substring(2, 11);
        localStorage.setItem("lifeline_user_id", currentId);
      }
      setUserId(currentId);

      try {
        const res = await fetch(`/api/get-user-data/${currentId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.profile) {
            setProfile(data.profile);
          }
          if (data.tasks) {
            setTasks(data.tasks);
          }
          if (data.schedules && data.schedules.length > 0) {
            // Sort to find the latest schedule
            const sorted = data.schedules.sort(
              (a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );
            setSchedule(sorted[0]);
            setStep("schedule");
          } else if (data.profile) {
            setStep("tasks");
          }
        }
      } catch (err) {
        console.error("Failed to restore session from Firestore:", err);
      } finally {
        setLoading(false);
      }
    }
    restoreSession();
  }, []);

  const handleSaveProfile = async (newProfile: UserProfile) => {
    setError("");
    const updatedProfile = { ...newProfile, userId };
    setProfile(updatedProfile);

    try {
      const res = await fetch("/api/save-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedProfile)
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to save profile");
      }
      setStep("tasks");
    } catch (err: any) {
      setError(err.message || "Network error. Failed to save your profile.");
    }
  };

  const handleGenerateSchedule = async (allTasks: Task[]) => {
    setError("");
    setIsGenerating(true);
    setTasks(allTasks);

    try {
      // 1. Save tasks to Firestore
      const saveRes = await fetch("/api/save-tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, tasks: allTasks })
      });
      if (!saveRes.ok) {
        const data = await saveRes.json();
        throw new Error(data.error || "Failed to save tasks");
      }

      // 2. Request schedule generation
      const genRes = await fetch("/api/generate-schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          userId, 
          profile, 
          tasks: allTasks,
          currentDate: new Date().toLocaleDateString('sv-SE')
        })
      });

      if (!genRes.ok) {
        const data = await genRes.json();
        throw new Error(data.error || "Failed to generate schedule");
      }

      const data = await genRes.json();
      setSchedule(data.schedule);
      setStep("schedule");
    } catch (err: any) {
      setError(err.message || "Failed to generate your plan. Please check your Gemini connection.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleReschedule = async (feedbackText: string) => {
    setError("");
    setIsGenerating(true);

    try {
      const res = await fetch("/api/reschedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          profile,
          tasks,
          previousSchedule: schedule,
          feedbackText,
          currentDate: new Date().toLocaleDateString('sv-SE')
        })
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to reschedule");
      }

      const data = await res.json();
      setSchedule(data.schedule);
      setSuccessMsg("AI Planner successfully updated your schedule based on your instruction!");
      setTimeout(() => setSuccessMsg(""), 5000);
    } catch (err: any) {
      setError(err.message || "Failed to reschedule. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAcceptSchedule = async () => {
    if (!schedule) return;
    setError("");
    try {
      const res = await fetch("/api/save-feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, scheduleId: schedule.id, feedback: "accepted" })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to save feedback");
      }
      setSuccessMsg("Awesome! Your feedback is saved. Push hard and finish those tasks before deadline!");
      setTimeout(() => setSuccessMsg(""), 6000);
    } catch (err: any) {
      setError(err.message || "Failed to submit feedback.");
    }
  };

  const handleToggleBlock = async (blockIndex: number) => {
    if (!schedule) return;
    
    const updatedTimeBlocks = schedule.timeBlocks.map((block, idx) => {
      if (idx === blockIndex) {
        return { ...block, completed: !block.completed };
      }
      return block;
    });

    const updatedSchedule = { ...schedule, timeBlocks: updatedTimeBlocks };
    setSchedule(updatedSchedule);

    try {
      const res = await fetch("/api/update-schedule-blocks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          scheduleId: schedule.id,
          timeBlocks: updatedTimeBlocks
        })
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to save progress");
      }
    } catch (err: any) {
      console.error("Error saving progress:", err);
      setError(err.message || "Failed to save progress update to cloud.");
      setSchedule(schedule); // rollback
    }
  };

  const handleRestart = () => {
    setStep("profile");
    setSchedule(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center text-[#e0e0e0]">
        <RefreshCw className="w-8 h-8 animate-spin text-emerald-500 mb-4" />
        <p className="text-zinc-400 font-mono text-xs uppercase tracking-widest">Initializing Lifeline Engine...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-[#e0e0e0] flex flex-col font-sans selection:bg-emerald-500 selection:text-black">
      {/* Top Header Navigation matching Sophisticated Dark theme */}
      <header className="h-20 border-b border-white/10 flex items-center justify-between px-6 sm:px-8 bg-black/40 backdrop-blur-md sticky top-0 z-40">
        <div className="flex items-center space-x-3.5">
          <div className="w-7 h-7 bg-emerald-500 rounded-sm rotate-45 flex items-center justify-center transform transition-all duration-300 hover:rotate-180 flex-shrink-0">
            <div className="w-3.5 h-3.5 bg-black rounded-full"></div>
          </div>
          <h1 className="text-2xl font-serif tracking-tight font-medium text-white flex items-center gap-2">
            Lifeline
            <span className="text-emerald-400 font-sans text-[10px] tracking-widest uppercase ml-1 bg-emerald-950/60 border border-emerald-500/20 px-2 py-0.5 rounded-sm">
              AI
            </span>
          </h1>
        </div>

        <div className="flex items-center space-x-4 sm:space-x-6">
          <div className="text-right hidden sm:block">
            <p className="text-[10px] uppercase tracking-widest text-zinc-500 mb-0.5">Operational Mode</p>
            <p className="text-xs font-mono text-emerald-400">Max Productivity Enabled</p>
          </div>
          <div className="w-9 h-9 rounded-full border border-white/20 bg-zinc-900 flex items-center justify-center text-xs font-mono text-white/80" title={`User Session ID: ${userId}`}>
            {userId.slice(-2).toUpperCase() || "JD"}
          </div>
        </div>
      </header>

      {/* Main Container Area */}
      <main className="flex-1 py-10">
        {/* Global Error Notice */}
        {error && (
          <div className="max-w-4xl mx-auto px-4 mb-6">
            <div className="p-4 bg-red-950/20 border border-red-500/30 rounded-lg text-red-200 text-xs font-mono flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-white uppercase tracking-wider">Planner Interrupted</h4>
                <p className="mt-1 text-zinc-400">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Global Success Banner */}
        {successMsg && (
          <div className="max-w-4xl mx-auto px-4 mb-6">
            <div className="p-4 bg-emerald-950/20 border border-emerald-500/30 rounded-lg text-emerald-200 text-xs font-mono flex items-start gap-3">
              <Info className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-white uppercase tracking-wider">Action Confirmed</h4>
                <p className="mt-1 text-zinc-400">{successMsg}</p>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic Multi-Step Routing with transitions */}
        <AnimatePresence mode="wait">
          {step === "welcome" && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
            >
              <WelcomeView onStart={() => setStep("profile")} />
            </motion.div>
          )}

          {step === "profile" && (
            <motion.div
              key="profile"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
            >
              <ProfileView
                initialProfile={profile}
                onSave={handleSaveProfile}
                onBack={() => setStep("welcome")}
              />
            </motion.div>
          )}

          {step === "tasks" && (
            <motion.div
              key="tasks"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
            >
              <TaskInputView
                initialTasks={tasks}
                onGenerate={handleGenerateSchedule}
                onBack={() => setStep("profile")}
                isGenerating={isGenerating}
              />
            </motion.div>
          )}

          {step === "schedule" && schedule && (
            <motion.div
              key="schedule"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
            >
              <ScheduleView
                schedule={schedule}
                onAccept={handleAcceptSchedule}
                onReschedule={handleReschedule}
                isRescheduling={isGenerating}
                onRestart={handleRestart}
                onToggleBlock={handleToggleBlock}
                userId={userId}
                profile={profile}
                tasks={tasks}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer Branding matching Sophisticated Dark styling */}
      <footer className="h-16 border-t border-white/5 bg-black flex items-center justify-between px-6 sm:px-8 text-[10px] font-mono text-zinc-600">
        <div>LIFELINE_v2.0.4 — READY_STATE</div>
        <div className="flex space-x-6">
          <span className="hidden xs:inline">FIRESTORE: CONNECTED</span>
          <span>LATENCY: 42MS</span>
          <span>GEMINI_3.5_FLASH</span>
        </div>
      </footer>
    </div>
  );
}
