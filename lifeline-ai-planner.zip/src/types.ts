export interface UserProfile {
  userId: string;
  role: "Student" | "Employee" | "Other";
  dailyFreeHours: number;
  wakeUpTime: string; // "HH:MM"
  sleepTime: string; // "HH:MM"
  currentStartTime?: string; // e.g., "6:30 PM" or "18:30"
  createdAt?: string;
}

export type TaskDifficulty = "Easy" | "Medium" | "Hard";
export type TaskType = "Study" | "Work" | "Project" | "Assignment" | "Health" | "Entertainment";

export interface Task {
  id: string;
  userId: string;
  name: string;
  deadline: string; // "YYYY-MM-DDTHH:MM"
  difficulty: TaskDifficulty;
  type: TaskType;
  createdAt?: string;
}

export interface TimeBlock {
  title: string;
  startTime: string; // "HH:MM"
  endTime: string; // "HH:MM"
  date: string; // "YYYY-MM-DD"
  type: TaskType | "Break" | "Buffer" | "Productive Activity";
  description: string;
  difficulty: TaskDifficulty | "None";
  isProductiveSuggestion: boolean;
  completed?: boolean;
}

export interface Schedule {
  id: string;
  userId: string;
  tasks: Task[];
  timeBlocks: TimeBlock[];
  recommendations: string[];
  explanation: string;
  feedback: "pending" | "accepted" | "rescheduled";
  createdAt: string;
}
